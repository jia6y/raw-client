# udp2raw-multiplatform

![image0](images/image0.PNG)

multi-platform(cross-platform) version of [udp2raw](https://github.com/wangyu-/udp2raw-tunnel), which supports Windows/Mac/BSD natively.

udp2raw的跨平台版，协议兼容[linux版的udpraw](https://github.com/wangyu-/udp2raw-tunnel)，可以直接运行在Windows、Mac、BSD上。

Check [Wiki](https://github.com/wangyu-/udp2raw-multiplatform/wiki) for details.

更多信息，见 [Wiki](https://github.com/wangyu-/udp2raw-multiplatform/wiki)。
